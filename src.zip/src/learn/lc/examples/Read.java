package learn.lc.examples;
import learn.lc.core.Example;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Read {
    public static List<Example> readData (String Filename) throws IOException{
        List<Example> examples=new ArrayList<Example>();
        BufferedReader bufferedReader = new BufferedReader(new FileReader(Filename));
        String curline;
        while((curline=bufferedReader.readLine())!=null) {
            String[] num = curline.split(",");
            Example example = new Example(num.length);
            example.output=Double.parseDouble(num[num.length-1]);
            example.inputs[0] = 1.0;
            for(int i=1;i<num.length;i++) {
                example.inputs[i]=Double.parseDouble(num[i-1]);
            }
            examples.add(example);
        }
        bufferedReader.close();
        return examples;
    }


}
