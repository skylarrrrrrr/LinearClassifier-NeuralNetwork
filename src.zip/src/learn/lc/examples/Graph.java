package learn.lc.examples;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ConcurrentModificationException;
import java.util.LinkedList;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Graph extends JFrame{
    int width=700;
    int height=400;
    Display display;

    public Graph(String name) {
        super(name);
        display=new Display();
        this.add(display);
        this.setSize(width, height);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public void addPoint(Double num, Double accurancy) {
        display.input(num,accurancy);
    }

    public class Display extends JPanel{
        LinkedList<Double[]> map;

        public Display() {
            super();
            map=new LinkedList<Double[]>();
        }

        @Override
        public void paintComponent(Graphics g) {
            if(map.isEmpty()) {
                return;
            }

            try {
                Double[] temp=map.getFirst();
                for(Double[] i:map) {
                    g.setColor(Color.BLACK);
                    if(temp.equals(i)) {
                        continue;
                    }

                    g.drawLine((int)(temp[0]*this.getWidth()),this.getHeight()-(int)(temp[1]*this.getHeight()),(int)(i[0]*this.getWidth()),this.getHeight()-(int)(i[1]*this.getHeight()));

                    temp=i;
                }
            }catch(ConcurrentModificationException e) {
                return;
            }
        }

        public void input(Double num, Double accuracy) {
            Double[] input_data= {num,accuracy};
            map.add(input_data);
            repaint();
        }
    }
}