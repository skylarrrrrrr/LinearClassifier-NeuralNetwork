package learn.lc.examples;

import java.io.IOException;
import java.util.List;

import learn.lc.core.DecayingLearningRateSchedule;
import learn.lc.core.Example;
import learn.lc.core.LogisticClassifier;

public class LogisticGraphMain {
    public static void test(String filename, int nsteps, double alpha) throws IOException{
        Graph graph=new Graph(filename);
        System.out.println("Filename: "+filename+"\tnstep: "+ nsteps +"\talpha: "+alpha);

        List<Example> examples= Read.readData(filename);
        int ninputs=examples.get(0).inputs.length;
        LogisticClassifier pc=new LogisticClassifier(ninputs) {

            public void trainingReport(List<Example> examples, int stepnum, int nsteps) {
                double accuracy = 1-squaredErrorPerSample(examples);
                System.out.println(stepnum + "\t" + accuracy);
                graph.addPoint(stepnum/(double)nsteps, accuracy);
            }

        };
        if(alpha>0) {
            pc.train(examples, nsteps, alpha);
        }
        else {
            pc.train(examples, 100000, new DecayingLearningRateSchedule());
        }

    }

    public static void readFile(String choice, int step, double alpha) throws IOException {
        if(choice.equals("EarthquakeClean")) {
            test("learn/lc/examples/earthquake-clean.data.txt", step, alpha);
        } else if(choice.equals("EarthquakeNoisy")) {
            test("learn/lc/examples/earthquake-noisy.data.txt", step, alpha);
        } else if(choice.equals("EarthquakeNoisyDecaying")) {
            step = 100000;
            alpha = -1;
            test("learn/lc/examples/earthquake-noisy.data.txt", step, alpha);
        }else if(choice.equals("HouseVotes")) {
            test("learn/lc/examples/house-votes-84.data.num.txt", step, alpha);
        }
    }

    public static void main(String[] argv) throws IOException {
        String choice = argv[0];
        int step = 10000;
        double alpha = 0.95;
        if(choice.equals("EarthquakeNoisyDecaying")){
            step = 100000;
            alpha = -1;
        }
        if(argv.length > 1){
            step = Integer.parseInt(argv[1]);
            alpha = Double.parseDouble(argv[2]);
        }
        readFile(choice, step, alpha);
    }

}